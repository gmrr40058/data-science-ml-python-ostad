print("Hello, World!") #This isppppVariables a comment

#print("Hello, World!")
print("Cheers, Mate!")

"""
This is a comment
written in
more than just one lineComments
"""
print("Hello, World!")

